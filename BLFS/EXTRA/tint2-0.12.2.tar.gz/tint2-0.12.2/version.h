#define VERSION_STRING "0.12-git-dirty"
