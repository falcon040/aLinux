<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>GR_FILENAME</name>
    <message numerus="yes">
        <location filename="output.cpp" line="1"/>
        <source>%n person</source>
        <comment>The total number of people displayed</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="output.cpp" line="2"/>
        <source>Name</source>
        <comment>The name of a person</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="output.cpp" line="3"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="output.cpp" line="4"/>
        <source>Birthday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="output.cpp" line="5"/>
        <source>Salary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="output.cpp" line="6"/>
        <source>Salary-age ratio</source>
        <translation>salaire-alto raison</translation>
    </message>
</context>
</TS>
